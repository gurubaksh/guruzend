var express = require('express');
var fetch = require('node-fetch');
var app = express();

let arr1 = [1,2,1,3,4,4,5,5,5];

let abc = arr1.reduce((e,a)=>{ (e.indexOf(a)==-1)?e.push(a):''; return e },[])

console.log(abc);


var server = app.listen(3000, function () {
   var host = server.address().address
   var port = server.address().port
   
  // console.log("Example app listening at http://%s:%s", host, port)
})
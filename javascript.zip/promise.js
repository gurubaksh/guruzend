var express = require('express');
var fetch = require('node-fetch');
var app = express();

const promise = new Promise (function(resolve, reject) {
	if(false) {
		resolve('some Message')
	}else {
		reject('Some error')
	}
});

/* promise.then(function(message) {
	console.log(message)
}).catch(function(error) {
	console.log((error) );
})
*/

promise.then(function(message) {
	console.log(message)
}, function(message){ 
console.log(message)
})

var server = app.listen(3000, function () {
   var host = server.address().address
   var port = server.address().port
   
  // console.log("Example app listening at http://%s:%s", host, port)
})
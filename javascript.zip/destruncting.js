var express = require('express');
var app = express();


var animal= {
	species: 'dog',
	weight: 23,
	sound: 'woof'
}

// destructing 
var {species, sound} = animal
console.log('The '+species + ' says ' + sound + '!')


// do destrcting by other way

makeSound({
	weight:23,
	sound: 'woof'
})

function makeSound({species = 'animal', sound}) {

	console.log('The '+ species + ' says ' + sound +'|')
}


var server = app.listen(3000, function () {
   var host = server.address().address
   var port = server.address().port
   
  // console.log("Example app listening at http://%s:%s", host, port)
})
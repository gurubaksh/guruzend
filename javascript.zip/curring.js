var express = require('express');
var fs = require('fs');
var _ = require('lodash');
var app = express();

// simple with arrow function

let dragon = (name, size, element) =>
name +' is a' +
size +' dragan that breath' +
element +'!'

console.log(dragon('fuluffkins', 'tiny', 'ligthing'))

// curring function

let dragon2 = 
name=>
size=>
element=>
name +' is a' +
size +' dragan that breath' +
element +'!'

console.log(dragon2('fuluffkins')('tiny')('ligthing'))



// curring by lodash convert simple function to curry
let dragon3 = _.curry(dragon)

console.log(dragon3('fuluffkins')('tiny')('ligthing'))



// for filter json
var animals = [
   {name:'Fuffykins', species: 'rabbit'},
   {name:'caro', species: 'dog'},
   {name:'hamilton', species:'dog'},
   {name:'harold', species:'fish'},
   {name:'ursula', species:'cat'},
   {name:'jimmy', species:'fish'},
]

var hasElement =  (species, obj) => obj.species === species

let dogs = animals.filter(x=>hasElement('dog', x))

console.log(dogs);


// curring

var hasElement2 = _.curry((species, obj) => obj.species === species)


let dogs2 = animals.filter(hasElement2('dog'))

console.log(dogs2);



var server = app.listen(3000, function () {
   var host = server.address().address
   var port = server.address().port
   
  // console.log("Example app listening at http://%s:%s", host, port)
})
var express = require('express');
var fetch = require('node-fetch');
var app = express();

let arr1 = [{id:1, name:'ram'}, {id:2, name:'john'}];
let arr2 = [{a_id:1, city:'haridwar'}];

const abc = arr2.map((e)=> arr1.map((v)=>{(e.a_id === v.id)?v.city = e.city:''; return v; }))

console.log(abc[0]);




var server = app.listen(3000, function () {
   var host = server.address().address
   var port = server.address().port
   
  // console.log("Example app listening at http://%s:%s", host, port)
})
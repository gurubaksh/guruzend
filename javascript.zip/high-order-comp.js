var express = require('express');
var app = express();

// function in variable for high order function
var triple = function(x) {
	return 3*x;	
}
var waflle = triple;
console.log(waflle(30));


// for filter json
var animals = [
   {name:'Fuffykins', species: 'rabbit'},
   {name:'caro', species: 'dog'},
   {name:'hamilton', species:'dog'},
   {name:'harold', species:'fish'},
   {name:'ursula', species:'cat'},
   {name:'jimmy', species:'fish'},
]

// by filter method execute any thing inside the fileter and return true or false;

var dogs = animals.filter(function(animal){
	return animal.species ==='dog';
})
console.log('----------only dogs --------------------');
console.log(dogs);

var otherAnimals =  animals.filter( function(animal){
	return animal.species !== 'dog';
})
console.log('---------------animals other then dogs ------------------------------------');
console.log(otherAnimals);










var server = app.listen(3000, function () {
   var host = server.address().address
   var port = server.address().port
   
  // console.log("Example app listening at http://%s:%s", host, port)
})
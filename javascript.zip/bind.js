var express = require('express');
var fetch = require('node-fetch');
var app = express();

function talk() {
	console.log(this.sound)
}

let boromir = {
	sound: 'one does not simply walk into mordor'
}

let talkBoundToBoromir = talk.bind(boromir)

talkBoundToBoromir();

var server = app.listen(3000, function () {
   var host = server.address().address
   var port = server.address().port
   
  // console.log("Example app listening at http://%s:%s", host, port)
})
var express = require('express');
var fetch = require('node-fetch');
var co = require('co');
var app = express();

/*fetch('https://jsonplaceholder.typicode.com/posts/1')
  .then(response => response.json())
  .then(json => console.log(json))
*/  
 
// handle promise by generator function by co

console.log('-----handle promise by generator function by co---------');
co(function *(){
 const uri = 'https://jsonplaceholder.typicode.com/posts/1'
 const response = yield fetch(uri)
 const post = yield response.json()
 const title = post.title
 console.log('Title:', title)
})


// own co implementation

console.log('----------------own co implementation -------------')

run(function *(){
 const uri = 'https://jsonplaceholder.typicode.com/posts/1'
 const response = yield fetch(uri)
 const post = yield response.json()
 const title = post.title
 console.log('Title:', title)
})

function run(generator) {
	const iterator = generator()
	const iteration = iterator.next()
	const promise = iteration.value
	promise.then(x=>{
		const anotherIterator =  iterator.next(x)
		const anotherPromise = anotherIterator.value
		anotherPromise.then(y=>iterator.next(y))
	})
}

// own co with recursion
console.log('-------------own co with recursion -------------------------');


run(function *(){
const  uri = 'https://jsonplaceholder.typicode.com/posts/1'
const  response = yield fetch(uri)
const post = yield response.json()
const title = post.title
return title

})
.catch(error =>console.error(error.stack))
.then(x=>console.log('run resulted in', x))


function run(generator) {
const iterator = generator()
function iterate(iteration) {
if(iteration.done) return iteration.value
const promise = iteration.value
return promise.then(x=>iterate(iterator.next(x)))
}
return iterate(iterator.next())
}



var server = app.listen(3000, function () {
   var host = server.address().address
   var port = server.address().port
   
  // console.log("Example app listening at http://%s:%s", host, port)
})
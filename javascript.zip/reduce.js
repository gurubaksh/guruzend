var express = require('express');
var app = express();


// want name of every animals
var orders = [
{amount:250},
{amount:400},
{amount:100},
{amount:325}
];

var totalAmount = orders.reduce(function(sum, order){
	return sum+order.amount
},0)

console.log(totalAmount);

// arrow function
var totalAmount = orders.reduce((sum, order) => {
	return sum+order.amount
},0)

console.log(totalAmount);

// if one line output 

var totalAmount = orders.reduce((sum, order) => sum+order.amount,0)
console.log(totalAmount);











var server = app.listen(3000, function () {
   var host = server.address().address
   var port = server.address().port
   
  // console.log("Example app listening at http://%s:%s", host, port)
})
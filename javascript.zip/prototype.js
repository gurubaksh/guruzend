var express = require('express');
var fetch = require('node-fetch');
var app = express();

function talk() {
	console.log(this.sound)
}

let animal = {
	talk
}

let cat = {
	sound: "meow"
}

Object.setPrototypeOf(cat, animal)
cat.talk()
console.log(cat);
console.log(animal)

let dog = {
	sound: 'woof'
}


Object.setPrototypeOf(dog, animal)
dog.talk()


var server = app.listen(3000, function () {
   var host = server.address().address
   var port = server.address().port
   
  // console.log("Example app listening at http://%s:%s", host, port)
})
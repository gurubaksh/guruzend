var express = require('express');
var urlExists = require('url-exists');
var app = express();

/*
Auther: Gurubaksh Singh
date: 03-02-18
purpose: check url
*/

app.get('/url', function (req, res) {
	 let url = req.param('url');
	let i = 0;

const checkUrl  = () => new Promise((resolve, reject) => {
  i++;
  
  urlExists(url, function(err, exists) {
		if(exists) {
			resolve(exists)
		} else if (i === 3) {
			resolve(exists);
		}
		else {
			reject();
		}	
	});


});

const repeat = () => new Promise((resolve, reject) => {
  let interval = setInterval(() => {
    checkUrl().then((response) => {
      
      clearInterval(interval);
      resolve(response);
    });
  }, 500);  
});

repeat()
  .then((response) => {
		if(response) {
			res.send( ` url exits url checked- ${i}`);
			
		} else {
			console.log(i);
			res.send( ` url not exits url checked- ${i}`);
			
		}	
	}); 	
	//res.send('url not exits');
	
	
})




var server = app.listen(3000, function () {
   var host = server.address().address
   var port = server.address().port
   
   console.log("Example app listening at http://%s:%s", host, port)
})
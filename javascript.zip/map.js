var express = require('express');
var app = express();


// want name of every animals
var animals = [
   {name:'Fuffykins', species: 'rabbit'},
   {name:'caro', species: 'dog'},
   {name:'hamilton', species:'dog'},
   {name:'harold', species:'fish'},
   {name:'ursula', species:'cat'},
   {name:'jimmy', species:'fish'},
]

var name = animals.map(function(animal){
	return animal.name;
	
})
console.log(name);

// with arrow function
var name = animals.map((animal)=>{ return animal.name; });
console.log(name);

// if logic is in one lineHeight

var name = animals.map((animal)=> animal.name );
console.log(name);









var server = app.listen(3000, function () {
   var host = server.address().address
   var port = server.address().port
   
  // console.log("Example app listening at http://%s:%s", host, port)
})
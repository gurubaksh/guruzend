var express = require('express');
var fetch = require('node-fetch');
var app = express();



async function fetchAvatarUrl(userId) {
	const response = await fetch('https://catappapi.herokuapp.com/users/123')
	const data = await response.json()
	const allCats = data.cats.map(async function(cats) { 
		const catResponse = await fetch(`https://catappapi.herokuapp.com/cats/${cats}`)
		const catData = await catResponse.json()
		return catData.imageUrl;
	
	})

	return await Promise.all(allCats)
	
	
}

const result = fetchAvatarUrl(123).then(cats=>console.log(cats))
console.log(result)



var server = app.listen(3000, function () {
   var host = server.address().address
   var port = server.address().port
   
  // console.log("Example app listening at http://%s:%s", host, port)
})
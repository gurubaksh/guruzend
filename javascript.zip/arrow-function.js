var express = require('express');
var app = express();


// arrow functions

const dragonEvents = [
	{type: 'attack', value: 12, target: 'player-dorkman'},
	{type: 'yawn', value:40},
	{type: 'eat', target: 'horse'},
	{type: 'attack', value: 23, target: 'player-fluffykins' },
	{type: 'attack', value: 12, target: 'player-dorkman' },
]

const totalDamgeOnDorkman = dragonEvents
	.filter(event => event.type === 'attack')
	.filter(event => event.target === 'player-dorkman')
	.map(event => event.value)
	.reduce((prev, value)=> (prev || 0) + value)
	
console.log(totalDamgeOnDorkman)


var server = app.listen(3000, function () {
   var host = server.address().address
   var port = server.address().port
   
  // console.log("Example app listening at http://%s:%s", host, port)
})
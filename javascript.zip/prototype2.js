var express = require('express');
var fetch = require('node-fetch');
var app = express();

function Person(saying) {
	this.saying = saying
}

Person.prototype.talk = function() {
	console.log('i say', this.saying)
}

var crockford = new Person('abcdefgh')

crockford.talk()


var server = app.listen(3000, function () {
   var host = server.address().address
   var port = server.address().port
   
  // console.log("Example app listening at http://%s:%s", host, port)
})
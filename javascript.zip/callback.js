var express = require('express');
var fetch = require('node-fetch');
var app = express();

first(2, function(prev, err){
		
		if(!err) { 
			second(prev, function(prev2, err){
				if(!err) { 
					third(prev2, function(prev3, err){
						console.log(prev3);
					})
				}
			});
		}

})


function first(fs, callback) {
	callback((fs+2), false)	
}

function second(fs, callback) {
	callback((fs+2), false)	
}
function third(fs, callback) {
	callback((fs+2), false)
}

var server = app.listen(3000, function () {
   var host = server.address().address
   var port = server.address().port
   
  // console.log("Example app listening at http://%s:%s", host, port)
})
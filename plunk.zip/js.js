var personArray = [
    {
        id: 0,
        name: 'John',
        location: 'USA'
    },
    {
        id: 1,
        name: 'Mary',
        location: 'Germany'
    }
];

function getPerson(id) {
    for( var i=0;i<personArray.length;i++) {
        if(personArray[i].id == id)
            return personArray[i];
    }  
        return {
            id: "",
            name: "nf",
            location: "loc"
        };
    
}

ngApp.controller('listController',function($scope){
    ajaxUtils.simulate(function(){
        $scope.$apply(function(){
            $scope.personArray = personArray;
        });
        $('ul.ngRepeat').listview('refresh');
    });
});

ngApp.controller('viewController',function($scope, $routeParams, $location){
    ajaxUtils.simulate(function(){
        $scope.$apply(function(){
            $scope.person = getPerson($routeParams.id);
        });
    });
    $scope.delete = function(person) {
        if(confirm("You sure?")) {
            var index = $.inArray(person, personArray);
            personArray.splice(index,1);
            $location.path('/list');
        }
    };
});

ngApp.controller('editController',function($scope, $routeParams, $location){
    $scope.person = getPerson($routeParams.id);
    $scope.save = function() {
        //model already updated
        $location.path('/view/'+$scope.person.id);
    };
});
ngApp.controller('createController',function($scope, $location){
    //$scope.personArray = personArray;
    $scope.person = {
        id: personArray.length,
        name: '',
        location: ''
    };
    $scope.save = function() {
        personArray.push($scope.person);
        $location.path('/list');
    };
});



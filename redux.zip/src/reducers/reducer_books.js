export default function(){
	return [
	{title : 'javascript', pages:101},
	{title : 'harry potter', pages:1031},
	{title : 'the dart tower', pages:1201},
	{title : 'Got', pages:1010},
	{title : 'eloquent ruby', pages:1401}


	]
}
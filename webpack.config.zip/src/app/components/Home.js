import React from "react";

export class Home extends React.Component {
    render() {
        return (
            <div>
                <h3>Home</h3>
            </div>
        );
    }
}
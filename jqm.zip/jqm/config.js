$.mobile.linkBindingEnabled = false;
$.mobile.hashListeningEnabled = false;
var ngApp = angular.module('app', ['ngRoute']);
ngApp.config(['$routeProvider',
  function($routeProvider) {
    $routeProvider.
      when('/3', {
        templateUrl: '3.html',
        //controller: 'editController'
      }).
      when('/2', {
        templateUrl: '2.html',
        //controller: 'editController'
      }).
      when('/1', {
          templateUrl: '1.html',
          //controller: 'listController'
      }).
      otherwise({
        redirectTo: '/1'
      });
  }]);

ngApp.directive('jqm', function($timeout) {
  return {
    link: function(scope, elm, attr) {
        $timeout(function(){
            elm.trigger('create');
        });
    }
  };
});

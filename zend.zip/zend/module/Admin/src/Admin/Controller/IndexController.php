<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2015 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Admin\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

use Zend\InputFilter\InputFilter;
use Zend\InputFilter\Input;
use Zend\Validator;

use Admin\Model\Users; // <-- Add this import


class IndexController extends AbstractActionController
{
	
	protected $usersTable;
				protected $storage;
			protected $authservice;
	public function getUsersTable()
     {
         if (!$this->usersTable) {
             $sm = $this->getServiceLocator();
             $this->usersTable = $sm->get('Admin\Model\UsersTable');
         }
         return $this->usersTable;
     }
	 
    public function indexAction()
    {
		
		$tt =$this->getUsersTable()->fetchAll();
		//print_r($tt); die;
        return new ViewModel(array(
             'indexs' => $this->getUsersTable()->fetchAll(),
         ));
		
        return new ViewModel();
    }
	
	public function loginuserAction() 
	{
		$request = $this->getRequest();
		if ($request->isPost()) {
			$data = $request->getPost();
						$this->getAuthService()
						->getAdapter()
						->setIdentity($data['email'])
						->setCredential('123456');
						$result = $this->getAuthService()->authenticate();
						var_dump($result); die;
			$email = new Input('email');
			$email->getValidatorChain()->attach(new Validator\EmailAddress());
			$inputFilter = new InputFilter();
			$inputFilter->add($email)
            ->setData($_POST);
			if ($inputFilter->isValid()) {
				echo "The form is valid\n";
			} else {
				echo "The form is not valid\n";
					foreach ($inputFilter->getInvalidInput() as $error) {
						print_r($error->getMessages());
    }
}
			
			
			
			
			
			var_dump($data);
		}
		
		exit(0);	
	}
	private function getAuthService()
			{
				if (! $this->authservice) {
					$this->authservice = $this->getServiceLocator()->get('AuthService');
				}
				return $this->authservice;
			}
}

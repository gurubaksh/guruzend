<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2015 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Admin;

use Zend\Mvc\ModuleRouteListener;
use Zend\Mvc\MvcEvent;

use Admin\Model\Users;
use Admin\Model\UsersTable;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
use Zend\Authentication\Adapter\DbTable as DbAuthAdapter;
use Zend\Authentication\AuthenticationService;

class Module
{
    public function onBootstrap(MvcEvent $e)
    {
          $eventManager   = $e->getApplication()->getEventManager();
        $moduleRouteListener = new ModuleRouteListener();
        $moduleRouteListener->attach($eventManager);
        
		$eventManager->getSharedManager()->attach('Zend\Mvc\Controller\AbstractActionController', 'dispatch', function($event) {
            $controller      = $event->getTarget();
            $controllerName  = get_class($controller);
           $moduleNamespace = substr($controllerName, 0, strpos($controllerName, '\\'));
		 
            $configs         = $event->getApplication()->getServiceManager()->get('config'); 
			$configs['view_manager']['template_map']['layout/layout'] = $configs['view_manager']['template_map']['admin/layout/layout'];
            if (isset($configs['moduleLayouts'][$moduleNamespace])) {
                $controller->layout($configs['moduleLayouts'][$moduleNamespace]);
            }
        }, 100);
    }

    public function getConfig()
    {
        return include __DIR__ . '/config/module.config.php';
    }
	
public function getServiceConfig()
 {
 return array(
 'factories' => array(
 'Admin\Model\UsersTable' => function($sm) {
 $tableGateway = $sm->get('UsersTableGateway');
 $table = new UsersTable($tableGateway);
 return $table;
 },
 'UsersTableGateway' => function ($sm) {
 $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
 $resultSetPrototype = new ResultSet();
 $resultSetPrototype->setArrayObjectPrototype(new Users());
 return new TableGateway('users', $dbAdapter, null, $resultSetPrototype);
 },
  'AuthService' => function ($serviceManager) {
                    $adapter = $serviceManager->get('Zend\Db\Adapter\Adapter');
                    $dbAuthAdapter = new DbAuthAdapter ( $adapter, 'users', 'email', 'password' );
                    	
                    $auth = new AuthenticationService();
                    $auth->setAdapter ( $dbAuthAdapter );
                    return $auth;
                }
 ),
 );
 }

    public function getAutoloaderConfig()
    {
        return array(
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
                ),
            ),
        );
    }
}

<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2015 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Index\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

class IndexController extends AbstractActionController
{
	
	protected $indexTable;
	
	 public function getIndexTable()
     {
         if (!$this->indexTable) {
             $sm = $this->getServiceLocator();
             $this->indexTable = $sm->get('Index\Model\IndexTable');
         }
         return $this->indexTable;
     }
    public function indexAction()
    {
		$tt =$this->getIndexTable()->fetchAll();
		//print_r($tt); die;
        return new ViewModel(array(
             'indexs' => $this->getIndexTable()->fetchAll(),
         ));
    }
	public function testAction()
	{ echo 'jjjj';
		die;
	}
}
